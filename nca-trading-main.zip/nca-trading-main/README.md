# NCA Trading
